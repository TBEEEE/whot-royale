# WHOT Royale

A playable real-time Nigerian WHOT-inspired card game for 2–6 players. No accounts. Private codes or quick-match public lobbies.

## Run

Requires Node.js 20+.

```bash
npm install
npm test
npm start
```

Open http://localhost:3000 on two browser tabs or devices on the same network. For external devices, deploy the service to a public Node.js host.

## Deploy to Render

1. Push this folder to a GitHub repository.
2. Create a **Web Service** in Render pointing to the repository.
3. Set build command `npm install` and start command `npm start`.
4. Use the resulting HTTPS URL to create a room and share its invite link.
5. Choose a single always-on instance for this prototype; do not enable multiple replicas without a shared state adapter.

## Rules (Version 0.1 house variant)

- Two to six players; each receives five cards.
- Match the top discard's shape or number; WHOT 20 is wild and chooses a shape.
- 1: Hold On (same player takes another turn).
- 2: Pick Two (next player draws 2 and loses turn).
- 5: Pick Three (next player draws 3 and loses turn).
- 8: Suspension (skip next player).
- 14: General Market (all other players draw 1).
- Draw exactly one card if you cannot or do not want to play; drawing ends the turn.
- No stacking penalties in this variant. Turns are clockwise.
- First player to empty their hand wins. Winner gains the total value of all opponents' remaining cards; WHOT cards count 20.
- Room host starts the game and next round. Score persists across rounds in the same process.

## Architecture and security

Express serves the web client. Socket.IO handles live state updates. All moves are validated server-side; only the recipient's own cards are included in their state. Reconnection uses a random secret token stored in localStorage. Names and chat are length-limited and rendered as text. Room data is held in server memory and is removed after 24 hours or after a prolonged idle period. A public matchmaking room is created on demand.

## Current limitations and hardening before a contest submission

- In-memory state is lost when the server restarts. Add Redis or a persistent store before production.
- If a player disconnects during their turn, the game waits. Add host-approved skip or a timeout/bot replacement.
- No chat moderation, rate limiting, telemetry, automated browser E2E suite, or abuse protection yet.
- No spectator mode or player removal; the room is fixed once a round starts.
- No deployment has been performed by this package; a public URL requires hosting.
- Rules differ across Nigerian households; adjust house rules after playtesting.
- Add client/server integration tests and verify on two physical devices before claiming completion.

## Acceptance checklist

- [ ] Two remote devices join the same room by code
- [ ] Six-player room capacity enforced; seventh player rejected
- [ ] Public quick match joins waiting public room
- [ ] Each player sees only their own hand
- [ ] Illegal moves rejected by server
- [ ] Action cards update every connected client
- [ ] Refresh restores session and hand
- [ ] Chat is synchronized and displayed safely
- [ ] Scores survive next round
- [ ] Mobile browser works on iOS and Android
- [ ] Public HTTPS deployment works without login


## Version 0.2 updates
- A reconnecting session invalidates its old socket association.
- Duplicate room joins are rejected, and chat is rate-limited to one message every 800ms.
- Live connection status, round scores and clearer turn instructions appear in the browser.
- Added a Render Blueprint (`render.yaml`) and four additional engine tests.

## Important production limitations
Rooms live in one Node.js process memory. Deploy exactly one instance with sticky WebSocket connections; restarts lose active games. A future production build should use a shared durable store and the Socket.IO Redis adapter. Player identity is a browser-local bearer token, not an account. Avoid sharing the token. This project has not yet been externally deployed or load-tested.
