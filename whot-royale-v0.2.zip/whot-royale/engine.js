import { randomInt } from 'node:crypto';
export const SHAPES=['circle','triangle','cross','square','star'];
const NUMBERS={circle:[1,2,3,4,5,7,8,10,11,12,13,14],triangle:[1,2,3,4,5,7,8,10,11,12,13,14],cross:[1,2,3,5,7,10,11,13,14],square:[1,2,3,5,7,10,11,13,14],star:[1,2,3,4,5,7,8]};
export function deck(){let id=0;return [...SHAPES.flatMap(shape=>NUMBERS[shape].map(number=>({id:++id,shape,number}))),...Array.from({length:5},()=>({id:++id,shape:'whot',number:20}))]}
export function shuffle(cards){let a=[...cards];for(let i=a.length-1;i>0;i--){let j=randomInt(i+1);[a[i],a[j]]=[a[j],a[i]]}return a}
export function canPlay(card,top,chosenShape){return card.number===20||card.shape===(chosenShape||top.shape)||card.number===top.number}
export function action(card){return ({1:'hold',2:'pick2',5:'pick3',8:'suspend',14:'general-market',20:'choose'})[card.number]||'normal'}
export function nextIndex(i,step,count){return (i+step+count)%count}
export function score(hand){return hand.reduce((sum,c)=>sum+(c.number===20?20:c.number),0)}
export function makeGame(players){const pile=shuffle(deck());const hands={};for(const p of players)hands[p.id]=Array.from({length:5},()=>pile.pop());let top=pile.pop();while(top.number===20){pile.unshift(top);top=pile.pop()}return {hands,draw:pile,discard:[top],turn:0,chosenShape:null,pending:0,phase:'playing',winner:null,round:1,log:['Round started'],scores:Object.fromEntries(players.map(p=>[p.id,0]))}}
export function replenish(game){if(game.draw.length)return;const top=game.discard.pop();game.draw=shuffle(game.discard);game.discard=[top]}
export function drawCards(game,id,count){const out=[];for(let i=0;i<count;i++){replenish(game);if(!game.draw.length)break;const c=game.draw.pop();game.hands[id].push(c);out.push(c)}return out}
