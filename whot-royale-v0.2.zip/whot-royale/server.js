import express from 'express';
import {createServer} from 'node:http';
import {Server} from 'socket.io';
import {randomBytes,randomUUID} from 'node:crypto';
import {makeGame,canPlay,action,SHAPES,nextIndex,drawCards,score} from './engine.js';
const app=express(),http=createServer(app),io=new Server(http,{cors:{origin:false}});app.use(express.static('public'));
app.get('/health',(_,res)=>res.json({ok:true,rooms:rooms.size}));
const rooms=new Map();const MAX=6;
const chatCooldown=new Map();
const code=()=>randomBytes(4).toString('hex').slice(0,6).toUpperCase();
const cleanName=n=>String(n||'Player').trim().slice(0,18).replace(/[<>]/g,'')||'Player';
const fail=(socket,msg)=>socket.emit('errorMessage',msg);
function publicState(room,id){const g=room.game;return {code:room.code,host:room.host,players:room.players.map(p=>({id:p.id,name:p.name,connected:p.connected,cards:g?.hands[p.id]?.length||0,score:g?.scores[p.id]||0})),started:!!g,game:g?{top:g.discard.at(-1),chosenShape:g.chosenShape,turn:room.players[g.turn]?.id,phase:g.phase,winner:g.winner,pending:g.pending,round:g.round,hand:g.hands[id]||[],drawCount:g.draw.length,log:g.log.slice(-6)}:null,me:id,chat:room.chat.slice(-25)}}
function broadcast(room){for(const p of room.players){if(p.socket)io.to(p.socket).emit('state',publicState(room,p.id))}}
function attach(socket,room,p){if(p.socket&&p.socket!==socket.id){const old=io.sockets.sockets.get(p.socket);if(old){old.data={};old.leave(room.code);old.emit('errorMessage','This session was opened on another device.')}}p.socket=socket.id;p.connected=true;socket.data={id:p.id,code:room.code};socket.join(room.code);socket.emit('identity',{id:p.id,token:p.token,code:room.code});broadcast(room)}
function createPlayer(name){return {id:randomUUID(),token:randomBytes(24).toString('hex'),name:cleanName(name),socket:null,connected:false}}
function advance(room,steps=1){room.game.turn=nextIndex(room.game.turn,steps,room.players.length)}
function log(g,s){g.log.push(s);if(g.log.length>40)g.log.shift()}
function finish(room,id){const g=room.game;g.phase='finished';g.winner=id;for(const p of room.players)if(p.id!==id)g.scores[id]+=score(g.hands[p.id]);log(g,`${room.players.find(p=>p.id===id).name} wins the round!`)}
io.on('connection',socket=>{
 socket.on('create',({name}={})=>{if(socket.data.code)return fail(socket,'Already in a room. Leave it first.');const p=createPlayer(name);let c;do{c=code()}while(rooms.has(c));const r={code:c,host:p.id,players:[p],game:null,chat:[],created:Date.now(),public:false};rooms.set(c,r);attach(socket,r,p)});
 socket.on('join',({code:c,name}={})=>{if(socket.data.code)return fail(socket,'Already in a room. Leave it first.');const r=rooms.get(String(c||'').trim().toUpperCase());if(!r)return fail(socket,'Room not found');if(r.game)return fail(socket,'Game already started. Reconnect if you were playing.');if(r.players.length>=MAX)return fail(socket,'Room full');const p=createPlayer(name);r.players.push(p);attach(socket,r,p)});
 socket.on('quickJoin',({name}={})=>{if(socket.data.code)return fail(socket,'Already in a room. Leave it first.');let r=[...rooms.values()].find(r=>r.public&&!r.game&&r.players.length<MAX);if(!r){const p=createPlayer(name);let c;do{c=code()}while(rooms.has(c));r={code:c,host:p.id,players:[p],game:null,chat:[],created:Date.now(),public:true};rooms.set(c,r);attach(socket,r,p)}else{const p=createPlayer(name);r.players.push(p);attach(socket,r,p)}});
 socket.on('reconnectPlayer',({code:c,id,token}={})=>{if(socket.data.code)return;const r=rooms.get(String(c||'').toUpperCase()),p=r?.players.find(p=>p.id===id&&p.token===token);if(!p)return fail(socket,'Saved session expired');attach(socket,r,p)});
 socket.on('setPublic',value=>{const r=rooms.get(socket.data.code);if(!r||r.host!==socket.data.id||r.game)return;r.public=!!value;broadcast(r)});
 socket.on('start',()=>{const r=rooms.get(socket.data.code);if(!r||r.host!==socket.data.id)return;if(r.players.length<2)return fail(socket,'Need at least two players');if(r.game)return;r.game=makeGame(r.players);broadcast(r)});
 socket.on('play',({cardId,shape}={})=>{const r=rooms.get(socket.data.code),g=r?.game,id=socket.data.id;if(!g||g.phase!=='playing'||r.players[g.turn]?.id!==id)return fail(socket,'Not your turn');const hand=g.hands[id],idx=hand.findIndex(c=>c.id===cardId);if(idx<0)return fail(socket,'Card not in your hand');const c=hand[idx];if(g.pending)return fail(socket,'Resolve your penalty first');if(!canPlay(c,g.discard.at(-1),g.chosenShape))return fail(socket,'Card does not match');if(c.number===20&&!SHAPES.includes(shape))return fail(socket,'Choose a valid shape');hand.splice(idx,1);g.discard.push(c);g.chosenShape=c.number===20?shape:null;const effect=action(c),who=r.players[g.turn].name;log(g,`${who} played ${c.number} ${c.shape}`);if(!hand.length){finish(r,id);return broadcast(r)}if(effect==='pick2'||effect==='pick3'){advance(r);g.pending=effect==='pick2'?2:3}else if(effect==='general-market'){for(const p of r.players)if(p.id!==id)drawCards(g,p.id,1);advance(r)}else if(effect==='hold'){/* same player */}else if(effect==='suspend'){advance(r,2)}else advance(r);broadcast(r)});
 socket.on('draw',()=>{const r=rooms.get(socket.data.code),g=r?.game,id=socket.data.id;if(!g||g.phase!=='playing'||r.players[g.turn]?.id!==id)return fail(socket,'Not your turn');const n=g.pending||1;drawCards(g,id,n);log(g,`${r.players[g.turn].name} drew ${n} card(s)`);g.pending=0;advance(r);broadcast(r)});
 socket.on('nextRound',()=>{const r=rooms.get(socket.data.code),g=r?.game;if(!g||g.phase!=='finished'||r.host!==socket.data.id)return;const scores=g.scores,round=g.round;r.game=makeGame(r.players);r.game.scores=scores;r.game.round=round+1;broadcast(r)});
 socket.on('chat',message=>{const now=Date.now();if(now-(chatCooldown.get(socket.id)||0)<800)return fail(socket,'Please wait before sending another message');chatCooldown.set(socket.id,now);const r=rooms.get(socket.data.code),p=r?.players.find(p=>p.id===socket.data.id);if(!r||!p)return;const text=String(message||'').trim().slice(0,120).replace(/[<>\x00-\x1F]/g,'');if(!text)return;r.chat.push({name:p.name,text});if(r.chat.length>50)r.chat.shift();broadcast(r)});
 socket.on('disconnect',()=>{chatCooldown.delete(socket.id);const r=rooms.get(socket.data.code),p=r?.players.find(p=>p.id===socket.data.id);if(p&&p.socket===socket.id){p.connected=false;p.socket=null;broadcast(r)}});
});
setInterval(()=>{for(const [c,r] of rooms)if(Date.now()-r.created>24*3600e3||(!r.players.some(p=>p.connected)&&Date.now()-r.created>2*3600e3))rooms.delete(c)},3600000).unref();
http.listen(process.env.PORT||3000,()=>console.log('WHOT Royale listening on',process.env.PORT||3000));
