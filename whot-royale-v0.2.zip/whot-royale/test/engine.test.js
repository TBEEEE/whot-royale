import test from 'node:test';import assert from 'node:assert/strict';import {deck,shuffle,canPlay,action,makeGame,drawCards,nextIndex,score} from '../engine.js';
test('deck has unique ids and WHOT cards',()=>{const d=deck();assert.equal(new Set(d.map(c=>c.id)).size,d.length);assert.equal(d.filter(c=>c.number===20).length,5)});
test('shuffle preserves cards',()=>assert.deepEqual(shuffle(deck()).map(c=>c.id).sort((a,b)=>a-b),deck().map(c=>c.id).sort((a,b)=>a-b)));
test('match shape, number or wild',()=>{const top={shape:'circle',number:3};assert.equal(canPlay({shape:'circle',number:7},top),true);assert.equal(canPlay({shape:'star',number:3},top),true);assert.equal(canPlay({shape:'star',number:20},top),true);assert.equal(canPlay({shape:'star',number:4},top),false);assert.equal(canPlay({shape:'star',number:4},top,'star'),true)});
test('action mappings',()=>{assert.equal(action({number:14}),'general-market');assert.equal(action({number:8}),'suspend')});
test('game deals five each',()=>{const g=makeGame([{id:'a'},{id:'b'}]);assert.equal(g.hands.a.length,5);assert.equal(g.hands.b.length,5);assert.notEqual(g.discard[0].number,20);assert.equal(drawCards(g,'a',2).length,2)});
test('turn wrap and score',()=>{assert.equal(nextIndex(2,2,3),1);assert.equal(score([{number:20},{number:5}]),25)});
